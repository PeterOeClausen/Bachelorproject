﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DROM_Client.Models.ObjectsOptimizedForUI
{
    public class DataReceivedFromAPI
    {
        public bool Success { get; set; }
        public string qwerty { get; set; }
    }
}
